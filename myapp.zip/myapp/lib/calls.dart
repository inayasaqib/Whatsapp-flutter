import 'package:flutter/material.dart';
import 'package:myapp/chats.dart';
import 'package:myapp/status.dart';

class Calls extends StatelessWidget {
  const Calls({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
     titleTextStyle: const TextStyle(color: Colors.white, fontSize: 30),
        title:const Text("Whatsapp"),
        backgroundColor: const Color.fromARGB(255, 6, 108, 76),
      actions:const [
         Icon(
          Icons.search,
          color: Colors.white,
          )
        ],
      ),
 body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  color: const Color.fromARGB(255, 6, 108, 76),
                  height: 30,
                  child: Row(
                    children: [
                      const SizedBox(width: 130, child: Center(child: Icon(Icons.camera_alt, color: Colors.white))),
                      ElevatedButton(
                        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Chats())),
                        style: ElevatedButton.styleFrom(
                          fixedSize: const Size(250, 25),
                          backgroundColor: const Color.fromARGB(255, 6, 108, 76),
                          textStyle: const TextStyle(fontSize: 20, color: Colors.white),
                        ),
                        child: const Text("Status"),
                      ),
                      ElevatedButton(
                        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Status())),
                        style: ElevatedButton.styleFrom(
                          fixedSize: const Size(250, 25),
                          backgroundColor: const Color.fromARGB(255, 6, 108, 76),
                          textStyle: const TextStyle(fontSize: 20, color: Colors.white),
                        ),
                        child: const Text("Calls"),
                      ),
                      const Expanded(child: Center(child: Text('Calls', style: TextStyle(fontSize: 20, color: Colors.white)))),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: ListView(
              children:  [
                ListTile(
                  tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("Ifra"),
                  subtitle:const Text("16 minutes ago"),
                  trailing: const Icon(Icons.phone, color: Color.fromARGB(255, 6, 108, 76),),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHNtaWx5JTIwZmFjZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60'),
                  ),
                ),
                 Container(
                  height: 1,
                  width: 900,
                  color: const Color.fromARGB(255, 204, 204, 204),
                ),
                ListTile(
                  tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("Bro"),
                  subtitle:const Text("February 8, 18:40"),
                  trailing:const Icon(Icons.phone, color: Color.fromARGB(255, 6, 108, 76),),
                  leading: CircleAvatar(
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&')
                  )
                ), 
                Container(
                  height: 1,
                  width: 900,
                  color: const Color.fromARGB(255, 204, 204, 204),
                ),
                ListTile(
                    tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("Saqib"),
                  subtitle:const Text("Januaruary 24, 17:20"),
                  trailing: const Icon(Icons.phone, color: Color.fromARGB(255, 6, 108, 76),),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&')
                  )
                ),
                Container(
                  height: 1,
                  width: 900,
                  color: const Color.fromARGB(255, 204, 204, 204),
                ),
                ListTile(
                    tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("maredia"),
                  subtitle:const Text("January 20, 19:45"),
                  trailing:const Icon(Icons.video_call, color:Color.fromARGB(255, 6, 108, 76), ) ,
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&')
                  )
                )
              ]
            )
          )
        ]
      )
    );          
  }
  }