import 'package:flutter/material.dart';
import 'package:myapp/calls.dart';
import 'package:myapp/chats.dart';

class Status extends StatelessWidget {
  const Status({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
        titleTextStyle: const TextStyle(color: Colors.white, fontSize: 30,),
        title:const Text("Whatsapp"),
        backgroundColor: const Color.fromARGB(255, 6, 108, 76),
      actions:const [
         Icon(
          Icons.search,
          color: Colors.white,
          )
        ],
      ),
       body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  color: const Color.fromARGB(255, 6, 108, 76),
                  height: 30,
                  child: Row(
                    children: [
                      const SizedBox(width: 130, child: Center(child: Icon(Icons.camera_alt, color: Colors.white))),
                       ElevatedButton(
                        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Chats())),
                        style: ElevatedButton.styleFrom(
                          fixedSize: const Size(250, 25),
                          backgroundColor: const Color.fromARGB(255, 6, 108, 76),
                          textStyle: const TextStyle(fontSize: 20, color: Colors.white),
                        ),
                        child: const Text("Chats"),
                      ),
                      const Expanded(child: Center(child: Text('Status', style: TextStyle(fontSize: 20, color: Colors.white)))),
                   
                      ElevatedButton(
                        onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const Calls())),
                        style: ElevatedButton.styleFrom(
                          fixedSize: const Size(250, 25),
                          backgroundColor: const Color.fromARGB(255, 6, 108, 76),
                          textStyle: const TextStyle(fontSize: 20, color: Colors.white),
                        ),
                        child: const Text("Calls"),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: ListView(
              children:  [
                ListTile(
                    tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("My Status"),
                  subtitle:const Text("Tap to add status update"),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHNtaWx5JTIwZmFjZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60'),
                  ),
                ),
                Container(
                  height: 20,
                  width: 900,
                  color: const Color.fromARGB(255, 190, 187, 187),
                  child: Title(color: Colors.black, child: const Text("Viewed updates")),
                ),
                ListTile(
                  tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("Ifra"),
                  subtitle:const Text("15 minutes ago"),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHNtaWx5JTIwZmFjZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60'),
                  ),
                ),
                ListTile(
                  tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("Bro"),
                  subtitle:const Text("39 minutes ago"),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&')
                  )
                ),
                ListTile(
                   tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("maredia"),
                  subtitle:const Text("2 hours ago"),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&')
                  )
                ),
                ListTile(
                   tileColor: Colors.white,
                  textColor: Colors.black,
                  title:const Text("Saqib"),
                  subtitle:const Text("17 hours ago"),
                  leading: CircleAvatar(
                     radius: 19,
                    child: Image.network('https://images.unsplash.com/photo-1554151228-14d9def656e4?ixlib=rb-4.0.3&')
                  )
                ),
                Container(
               height: 20,
                  width: 900,
                  color: const Color.fromARGB(255, 190, 187, 187),
                  child: Title(color: Colors.black, child: const Text("Muted updates")),
                )
              ]
            )
          )
        ]
      )
    );          
  }
  }